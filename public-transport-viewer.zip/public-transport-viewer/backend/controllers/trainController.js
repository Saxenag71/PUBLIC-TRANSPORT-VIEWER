const api = require("../utils/apiClient");

// 🚆 Trains Between Stations
exports.search = async (req, res) => {
  try {
    const { from, to } = req.query;

    const response = await api.get("/trainsBetweenStations", {
      params: {
        fromStationCode: from,
        toStationCode: to
      }
    });

    res.json(response.data);
  } catch (err) {
    console.error(err.response?.data || err.message);
    res.status(500).json({ error: "Train search failed" });
  }
};
// 🚦 Running Status
exports.status = async (req, res) => {
  try {
    const response = await api.get("/trainStatus", {
      params: {
        trainNumber: req.params.trainNo
      }
    });

    res.json(response.data);
  } catch (err) {
    console.error(err.response?.data || err.message);
    res.status(500).json({ error: "Running status failed" });
  }
};
// 🚦 Running Status
exports.status = async (req, res) => {
  try {
    const response = await api.get("/trainStatus", {
      params: {
        trainNumber: req.params.trainNo
      }
    });

    res.json(response.data);
  } catch (err) {
    console.error(err.response?.data || err.message);
    res.status(500).json({ error: "Running status failed" });
  }
};
// 🕒 Timetable
exports.timetable = async (req, res) => {
  try {
    const response = await api.get("/trainSchedule", {
      params: {
        trainNumber: req.params.trainNo
      }
    });

    res.json(response.data);
  } catch (err) {
    console.error(err.response?.data || err.message);
    res.status(500).json({ error: "Timetable failed" });
  }
};
