const db = require("../utils/db");
const bcrypt = require("bcryptjs");

// ✅ REGISTER FUNCTION
const register = async (req, res) => {
  const { name, email, password } = req.body;

  if (!name || !email || !password) {
    return res.status(400).json({ msg: "All fields required" });
  }

  db.query("SELECT * FROM users WHERE email=?", [email], async (err, rows) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ msg: "DB error" });
    }

    if (rows.length > 0) {
      return res.json({ msg: "Email already registered" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    db.query(
      "INSERT INTO users (name,email,password) VALUES (?,?,?)",
      [name, email, hashedPassword],
      err2 => {
        if (err2) {
          console.error(err2);
          return res.status(500).json({ msg: "Insert failed" });
        }
        res.json({ msg: "Registration successful" });
      }
    );
  });
};

// ✅ LOGIN FUNCTION
const login = async (req, res) => {
  const { email, password } = req.body;

  db.query("SELECT * FROM users WHERE email=?", [email], async (err, rows) => {
    if (err) return res.status(500).json({ msg: "DB error" });

    if (rows.length === 0) {
      return res.json({ msg: "Invalid credentials" });
    }

    const match = await bcrypt.compare(password, rows[0].password);
    if (!match) {
      return res.json({ msg: "Invalid credentials" });
    }

    res.json({ msg: "Login successful" });
  });
};

// ✅ EXPORT PROPERLY
module.exports = {
  register,
  login
};
