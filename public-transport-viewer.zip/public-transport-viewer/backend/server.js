require("dotenv").config();
const express = require("express");
const path = require("path");
const app = express();

app.use(express.json());

// static frontend
app.use(express.static("public"));

// default route
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "login.html"));
});

// APIs
app.use("/api/auth", require("./routes/authRoutes"));
app.use("/api/trains", require("./routes/trainRoutes"));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log("MySQL Connected");
  console.log("Server running on port", PORT);
});
