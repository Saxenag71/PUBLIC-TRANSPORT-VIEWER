module.exports = {
  baseURL: "https://indian-railways-data-api.p.rapidapi.com",
  headers: {
    "X-RapidAPI-Key": process.env.RAPID_API_KEY,
    "X-RapidAPI-Host": process.env.RAPID_API_HOST
  }
};
