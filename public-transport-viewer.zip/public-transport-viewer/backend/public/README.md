# Public Transport Viewer – Indian Railways

✔ Login / Register  
✔ MySQL database  
✔ Encrypted password  
✔ Live Train Search  
✔ Live Running Status  
✔ Timetable  

Tech:
Node.js, Express, MySQL, RapidAPI
