function searchTrains() {
  const from = document.getElementById("from").value.trim();
  const to = document.getElementById("to").value.trim();

  if (!from || !to) {
    alert("Please enter station codes");
    return;
  }

  fetch(`http://localhost:5000/api/trains/search?from=${from}&to=${to}`)
    .then(res => res.json())
    .then(data => {
      document.getElementById("result").textContent =
        JSON.stringify(data, null, 2);
    })
    .catch(err => {
      alert("Network error while searching trains");
      console.error(err);
    });
}
