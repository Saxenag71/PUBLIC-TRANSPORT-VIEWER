function login() {
  fetch("http://localhost:5000/api/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      email: email.value,
      password: password.value
    })
  })
    .then(r => r.json())
    .then(d => {
      if (d.msg === "Login successful")
        location.href = "index.html";
      else alert(d.msg);
    });
}
