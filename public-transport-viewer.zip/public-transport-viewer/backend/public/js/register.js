function register() {
  console.log("Register clicked");

  fetch("http://localhost:5000/api/auth/register", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      name: document.getElementById("name").value,
      email: document.getElementById("email").value,
      password: document.getElementById("password").value
    })
  })
    .then(res => {
      console.log("Response status:", res.status);
      return res.json();
    })
    .then(data => {
      alert(data.msg);
      if (data.msg === "Registration successful") {
        window.location.href = "login.html";
      }
    })
    .catch(err => {
      console.error("FETCH ERROR:", err);
      alert("Backend not reachable");
    });
}
