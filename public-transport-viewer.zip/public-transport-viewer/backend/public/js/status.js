function getRunningStatus() {
  const trainNo = document.getElementById("trainNo").value;
  const date = document.getElementById("date").value;

  if (!trainNo || !date) {
    alert("Please enter train number and date");
    return;
  }

  fetch(`http://localhost:5000/api/trains/status/${trainNo}?date=${date}`)
    .then(res => res.json())
    .then(data => {
      document.getElementById("output").textContent =
        JSON.stringify(data, null, 2);
    })
    .catch(err => {
      alert("Network error in running status");
      console.error(err);
    });
}
