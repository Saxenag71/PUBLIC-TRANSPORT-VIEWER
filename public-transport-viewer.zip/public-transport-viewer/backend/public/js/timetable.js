function getTimetable() {
  const trainNo = document.getElementById("trainNo").value;

  if (!trainNo) {
    alert("Enter train number");
    return;
  }

  fetch(`http://localhost:5000/api/trains/timetable/${trainNo}`)
    .then(res => res.json())
    .then(data => {
      document.getElementById("output").textContent =
        JSON.stringify(data, null, 2);
    })
    .catch(err => {
      alert("Network error in timetable");
      console.error(err);
    });
}
