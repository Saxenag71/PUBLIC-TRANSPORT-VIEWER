const axios = require("axios");
const config = require("../config/apiConfig");

module.exports = axios.create({
  baseURL: config.baseURL,
  headers: config.headers
});
