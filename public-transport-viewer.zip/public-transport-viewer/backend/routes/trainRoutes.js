const router = require("express").Router();
const t = require("../controllers/trainController");

router.get("/search", t.search);
router.get("/status/:trainNo", t.status);
router.get("/timetable/:trainNo", t.timetable);

module.exports = router;
